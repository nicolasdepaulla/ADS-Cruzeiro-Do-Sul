/**
 * Widget de chat de suporte (SAC) flutuante, compartilhado pelas páginas
 * logadas. O histórico fica em sessionStorage -- some se fechar a aba,
 * mas sobrevive a navegar entre logado.html/pedidos.html/dashboard.html,
 * que são páginas separadas (sem isso, trocar de página reiniciaria a
 * conversa a cada clique).
 */
(function () {
  const CHAVE_HISTORICO = "conecta_chat_historico";
  const MAX_HISTORICO_GUARDADO = 20;

  function carregarHistorico() {
    try {
      const bruto = sessionStorage.getItem(CHAVE_HISTORICO);
      return bruto ? JSON.parse(bruto) : [];
    } catch (e) {
      return [];
    }
  }

  function salvarHistorico(historico) {
    try {
      sessionStorage.setItem(CHAVE_HISTORICO, JSON.stringify(historico.slice(-MAX_HISTORICO_GUARDADO)));
    } catch (e) {
      // sessionStorage indisponível (aba privada, por exemplo) -- a
      // conversa simplesmente não persiste entre páginas, sem travar nada.
    }
  }

  function montarBolha(papel, texto, escalada) {
    const bolha = document.createElement("div");
    bolha.className = "chat-msg chat-msg-" + papel + (escalada ? " chat-msg-escalada" : "");
    bolha.textContent = texto;
    return bolha;
  }

  document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("chatToggleBtn");
    const closeBtn = document.getElementById("chatCloseBtn");
    const panel = document.getElementById("chatPanel");
    const mensagensEl = document.getElementById("chatMensagens");
    const form = document.getElementById("chatForm");
    const input = document.getElementById("chatInput");

    if (!toggleBtn || !panel) return; // widget não está nesta página

    let historico = carregarHistorico();
    historico.forEach(function (m) {
      mensagensEl.appendChild(montarBolha(m.papel, m.conteudo, false));
    });
    if (historico.length) mensagensEl.scrollTop = mensagensEl.scrollHeight;

    toggleBtn.addEventListener("click", function () {
      panel.hidden = !panel.hidden;
      if (!panel.hidden) input.focus();
    });
    closeBtn.addEventListener("click", function () {
      panel.hidden = true;
    });

    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      const texto = input.value.trim();
      if (!texto) return;

      mensagensEl.appendChild(montarBolha("usuario", texto, false));
      mensagensEl.scrollTop = mensagensEl.scrollHeight;

      const historicoParaEnviar = historico.slice(-10);
      input.value = "";
      input.disabled = true;

      const carregando = document.createElement("div");
      carregando.className = "chat-msg chat-msg-assistente chat-msg-carregando";
      carregando.textContent = "Digitando...";
      mensagensEl.appendChild(carregando);
      mensagensEl.scrollTop = mensagensEl.scrollHeight;

      try {
        const resposta = await fetch("/chat/mensagem", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ mensagem: texto, historico: historicoParaEnviar }),
        });

        carregando.remove();

        const dados = await resposta.json().catch(() => ({}));

        if (resposta.ok) {
          mensagensEl.appendChild(montarBolha("assistente", dados.resposta, dados.escalar));
          historico.push({ papel: "usuario", conteudo: texto });
          historico.push({ papel: "assistente", conteudo: dados.resposta });
          salvarHistorico(historico);
        } else {
          const detalhe = typeof dados.detail === "string" ? dados.detail : "Não foi possível falar com o suporte agora. Tente novamente em instantes.";
          mensagensEl.appendChild(montarBolha("assistente", detalhe, true));
        }
      } catch (err) {
        carregando.remove();
        mensagensEl.appendChild(montarBolha("assistente", "Não foi possível conectar ao servidor.", true));
      } finally {
        input.disabled = false;
        input.focus();
        mensagensEl.scrollTop = mensagensEl.scrollHeight;
      }
    });
  });
})();
