"""
Testes do chat de suporte (SAC): formatação do catálogo pro prompt,
decisão de escalada, tratamento de erro da API, e o endpoint (autenticação
+ rate limiting continuam valendo, igual nas outras rotas).

Não chama a API da Anthropic de verdade em nenhum teste -- llm_client.perguntar
é mockado, igual o Mercado Pago é mockado nos testes de pagamento.
"""
import httpx
import pytest
from unittest.mock import AsyncMock
from anthropic import APIError
from fastapi.testclient import TestClient

from app.main import app
from app.core import deps
from app.core.config import settings
from app.services import chat_service
from app.services import pacote_service
from app.core import llm_client
from app.models.chat import ChatMensagemEntrada, MensagemHistorico

client = TestClient(app)

PACOTE_EXEMPLO = {
    "nome": "Pacote Imobiliário",
    "setor": "Imobiliário",
    "preco": 100.0,
    "quantidade_contatos": 100,
    "sessao": {"itens": ["Telefone", "E-mail corporativo", "CNPJ"]},
}


def _erro_api(mensagem="falhou"):
    request = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    return APIError(mensagem, request, body=None)


# ---------------------------------------------------------------------------
# _formatar_catalogo
# ---------------------------------------------------------------------------

def test_formatar_catalogo_lista_pacotes():
    texto = chat_service._formatar_catalogo([PACOTE_EXEMPLO])
    assert "Pacote Imobiliário" in texto
    assert "R$ 100.00" in texto
    assert "Telefone" in texto


def test_formatar_catalogo_vazio():
    texto = chat_service._formatar_catalogo([])
    assert "nenhum pacote" in texto.lower()


# ---------------------------------------------------------------------------
# chat_service.responder
# ---------------------------------------------------------------------------

async def test_responder_sem_escalada(monkeypatch):
    monkeypatch.setattr(pacote_service, "listar_todos", AsyncMock(return_value=[PACOTE_EXEMPLO]))
    monkeypatch.setattr(
        llm_client, "perguntar",
        lambda mensagem, historico_anthropic, catalogo_formatado: ("O pacote custa R$ 100,00.", None),
    )
    monkeypatch.setattr(settings, "anthropic_api_key", "chave-de-teste")

    resultado = await chat_service.responder(ChatMensagemEntrada(mensagem="Quanto custa o pacote imobiliário?"))

    assert resultado.escalar is False
    assert resultado.contato_humano is None
    assert "100,00" in resultado.resposta


async def test_responder_com_escalada_usa_contato_real(monkeypatch):
    monkeypatch.setattr(pacote_service, "listar_todos", AsyncMock(return_value=[]))
    monkeypatch.setattr(
        llm_client, "perguntar",
        lambda mensagem, historico_anthropic, catalogo_formatado: ("Entendo sua situação.", "cobrança indevida"),
    )
    monkeypatch.setattr(settings, "anthropic_api_key", "chave-de-teste")
    monkeypatch.setattr(settings, "suporte_contato_humano", "suporte-teste@exemplo.com")

    resultado = await chat_service.responder(ChatMensagemEntrada(mensagem="Fui cobrado duas vezes!"))

    assert resultado.escalar is True
    assert resultado.contato_humano == "suporte-teste@exemplo.com"
    assert "suporte-teste@exemplo.com" in resultado.resposta


async def test_responder_sem_api_key_retorna_503(monkeypatch):
    monkeypatch.setattr(settings, "anthropic_api_key", "")

    with pytest.raises(Exception) as exc:
        await chat_service.responder(ChatMensagemEntrada(mensagem="Oi"))

    assert exc.value.status_code == 503


async def test_responder_erro_da_api_retorna_503(monkeypatch):
    monkeypatch.setattr(pacote_service, "listar_todos", AsyncMock(return_value=[]))
    monkeypatch.setattr(settings, "anthropic_api_key", "chave-de-teste")

    def levanta_erro(*args, **kwargs):
        raise _erro_api()

    monkeypatch.setattr(llm_client, "perguntar", levanta_erro)

    with pytest.raises(Exception) as exc:
        await chat_service.responder(ChatMensagemEntrada(mensagem="Oi"))

    assert exc.value.status_code == 503


async def test_responder_resposta_vazia_escala_por_seguranca(monkeypatch):
    monkeypatch.setattr(pacote_service, "listar_todos", AsyncMock(return_value=[]))
    monkeypatch.setattr(settings, "anthropic_api_key", "chave-de-teste")
    monkeypatch.setattr(
        llm_client, "perguntar",
        lambda mensagem, historico_anthropic, catalogo_formatado: ("", None),
    )

    resultado = await chat_service.responder(ChatMensagemEntrada(mensagem="Oi"))

    assert resultado.escalar is True


def test_historico_limitado_a_10_mensagens_mesmo_que_schema_aceite_mais():
    historico = [MensagemHistorico(papel="usuario", conteudo=f"msg {i}") for i in range(20)]
    entrada = ChatMensagemEntrada(mensagem="última", historico=historico)

    resultado = chat_service._montar_historico_anthropic(entrada)

    assert len(resultado) == chat_service.MAX_MENSAGENS_HISTORICO
    assert resultado[-1]["content"] == "msg 19"


# ---------------------------------------------------------------------------
# Validação do schema de entrada
# ---------------------------------------------------------------------------

def test_mensagem_vazia_rejeitada():
    with pytest.raises(Exception):
        ChatMensagemEntrada(mensagem="")


def test_mensagem_muito_longa_rejeitada():
    with pytest.raises(Exception):
        ChatMensagemEntrada(mensagem="a" * 1001)


def test_papel_invalido_no_historico_rejeitado():
    with pytest.raises(Exception):
        MensagemHistorico(papel="sistema", conteudo="oi")


# ---------------------------------------------------------------------------
# POST /chat/mensagem (integração)
# ---------------------------------------------------------------------------

def test_endpoint_exige_autenticacao():
    resposta = client.post("/chat/mensagem", json={"mensagem": "Oi"})
    assert resposta.status_code == 401


def test_endpoint_retorna_resposta_quando_autenticado(monkeypatch):
    app.dependency_overrides[deps.get_current_user] = lambda: {"username": "cliente"}
    monkeypatch.setattr(
        chat_service, "responder",
        AsyncMock(return_value=__import__("app.models.chat", fromlist=["ChatMensagemSaida"]).ChatMensagemSaida(
            resposta="Olá! Como posso ajudar?", escalar=False,
        )),
    )

    try:
        resposta = client.post(
            "/chat/mensagem",
            json={"mensagem": "Oi"},
            headers={"Cookie": "authToken=qualquer"},
        )
    finally:
        app.dependency_overrides.pop(deps.get_current_user, None)

    assert resposta.status_code == 200
    assert resposta.json()["escalar"] is False
    assert "ajudar" in resposta.json()["resposta"]
