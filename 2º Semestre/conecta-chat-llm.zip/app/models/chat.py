from pydantic import BaseModel, Field


class MensagemHistorico(BaseModel):
    """Uma mensagem já trocada na conversa, enviada pelo front-end a cada
    pergunta nova pra dar contexto ao modelo (o backend não guarda
    histórico de conversa em banco nesta primeira versão)."""
    papel: str = Field(pattern="^(usuario|assistente)$")
    conteudo: str = Field(max_length=2000)


class ChatMensagemEntrada(BaseModel):
    mensagem: str = Field(min_length=1, max_length=1000)
    # Limitado a 20 entradas aqui na validação, e truncado de novo no
    # serviço (só as últimas N) -- não é só perfumaria, é pra não deixar
    # um histórico gigante inflar o custo/tamanho da chamada ao modelo.
    historico: list[MensagemHistorico] = Field(default_factory=list, max_length=20)


class ChatMensagemSaida(BaseModel):
    resposta: str
    escalar: bool
    contato_humano: str | None = None
