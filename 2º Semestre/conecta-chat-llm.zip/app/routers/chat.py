from fastapi import APIRouter, Depends, Request
from app.models.chat import ChatMensagemEntrada, ChatMensagemSaida
from app.services import chat_service
from app.core.deps import get_current_user
from app.core.limiter import limiter

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("/mensagem", response_model=ChatMensagemSaida)
@limiter.limit("20/minute")
async def enviar_mensagem(
    request: Request,
    entrada: ChatMensagemEntrada,
    usuario: dict = Depends(get_current_user),
):
    """
    Só usuário autenticado (cookie de sessão, igual o resto do sistema)
    pode falar com o chat -- evita abuso anônimo e, de quebra, dá pra
    identificar quem está conversando se algum dia precisar investigar.
    """
    return await chat_service.responder(entrada)
