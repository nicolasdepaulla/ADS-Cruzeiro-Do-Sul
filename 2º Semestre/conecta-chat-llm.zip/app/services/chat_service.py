"""
Orquestra uma mensagem do chat de suporte: busca o catálogo real de
pacotes (pra o modelo responder com dado verdadeiro, não "lembrança"),
monta o histórico no formato que a API da Anthropic espera, chama o
modelo e traduz o resultado pro formato que o front-end consome.
"""
import logging
from anthropic import APIError
from fastapi import HTTPException
from app.core.config import settings
from app.core import llm_client
from app.services import pacote_service
from app.models.chat import ChatMensagemEntrada, ChatMensagemSaida

logger = logging.getLogger("conecta.chat")

# Só as últimas N trocas vão pro modelo, mesmo que o front-end mande mais
# (o schema já limita a 20 -- isso aqui é uma segunda trava, server-side,
# que não depende de nada que vem do cliente).
MAX_MENSAGENS_HISTORICO = 10

MAPA_PAPEL = {"usuario": "user", "assistente": "assistant"}

MENSAGEM_SERVICO_INDISPONIVEL = (
    "No momento não consigo acessar o assistente de suporte. "
    f"Fale direto com a nossa equipe: {settings.suporte_contato_humano}"
)


def _formatar_catalogo(pacotes: list[dict]) -> str:
    if not pacotes:
        return "(nenhum pacote cadastrado no momento)"

    linhas = []
    for p in pacotes:
        itens = ", ".join(p["sessao"]["itens"])
        linhas.append(
            f"- {p['nome']} (setor: {p['setor']}): R$ {p['preco']:.2f} por "
            f"{p['quantidade_contatos']} contatos. Inclui: {itens}."
        )
    return "\n".join(linhas)


def _montar_historico_anthropic(entrada: ChatMensagemEntrada) -> list[dict]:
    recentes = entrada.historico[-MAX_MENSAGENS_HISTORICO:]
    return [{"role": MAPA_PAPEL[m.papel], "content": m.conteudo} for m in recentes]


async def responder(entrada: ChatMensagemEntrada) -> ChatMensagemSaida:
    if not settings.anthropic_api_key:
        # Sem chave configurada (dev sem .env preenchido, por exemplo) --
        # falha de forma clara em vez de tentar chamar a API e estourar
        # um erro genérico de autenticação.
        logger.error("chat: ANTHROPIC_API_KEY não configurada")
        raise HTTPException(status_code=503, detail=MENSAGEM_SERVICO_INDISPONIVEL)

    pacotes = await pacote_service.listar_todos()
    catalogo_formatado = _formatar_catalogo(pacotes)
    historico_anthropic = _montar_historico_anthropic(entrada)

    try:
        texto, motivo_escalada = llm_client.perguntar(
            mensagem=entrada.mensagem,
            historico_anthropic=historico_anthropic,
            catalogo_formatado=catalogo_formatado,
        )
    except APIError as e:
        logger.error("chat: erro ao chamar a API da Anthropic: %s", e)
        raise HTTPException(status_code=503, detail=MENSAGEM_SERVICO_INDISPONIVEL)

    if motivo_escalada:
        # A frase final de escalada é fixa (não deixamos o modelo compor
        # essa parte) -- garante que o contato mostrado é sempre o real,
        # e que a mensagem é sempre clara, nunca vaga.
        resposta = (
            f"{texto}\n\n"
            f"Vou te encaminhar para um atendente humano: {settings.suporte_contato_humano}"
        ).strip()
        return ChatMensagemSaida(resposta=resposta, escalar=True, contato_humano=settings.suporte_contato_humano)

    if not texto:
        # Salvaguarda: se por algum motivo o modelo não chamou a ferramenta
        # nem devolveu texto, não mandamos resposta vazia pro usuário --
        # escalamos, já que não temos nada confiável pra mostrar.
        logger.warning("chat: resposta do modelo veio vazia, escalando por segurança")
        return ChatMensagemSaida(
            resposta=f"Não consegui montar uma resposta agora. Fale com a nossa equipe: {settings.suporte_contato_humano}",
            escalar=True,
            contato_humano=settings.suporte_contato_humano,
        )

    return ChatMensagemSaida(resposta=texto, escalar=False)
